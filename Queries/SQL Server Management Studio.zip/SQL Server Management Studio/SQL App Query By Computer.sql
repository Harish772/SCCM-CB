Select DISTINCT SYS.Netbios_Name0,SYS.Resource_Domain_OR_Workgr0,SP.CompanyName, SP.ProductName, SP.ProductVersion

FROM v_GS_SoftwareProduct SP

JOIN v_R_System SYS ON SP.ResourceID=SYS.ResourceID

JOIN v_FullCollectionMembership fcm on sys.ResourceID=fcm.ResourceID 

WHERE fcm.CollectionID = 'AAA00C8D'

ORDER By SYS.Netbios_Name0, SP.CompanyName, SP.ProductName, SP.ProductVersion