Select sys.Name0 As Name, sys.user_name0 as UserName,
arp.DisplayName0 as DisplayName,
arp.Publisher0 as Publisher,
arp.Version0 as Version, max(arp.InstallDate0) AS InstallDate
FROM v_Add_Remove_Programs arp
JOIN v_R_System sys ON arp.ResourceID = sys.ResourceID
LEFT JOIN v_FullCollectionMembership fcm on SYS.ResourceID=fcm.ResourceID
LEFT JOIN v_R_User USR on SYS.User_Name0 = USR.User_Name0
WHERE (arp.DisplayName0 like '%Silverlight%')
and arp.Publisher0 like '%Microsoft%'
GROUP BY sys.name0,sys.user_name0, arp.displayName0, arp.publisher0, arp.Version0
ORDER BY arp.displayName0, arp.publisher0