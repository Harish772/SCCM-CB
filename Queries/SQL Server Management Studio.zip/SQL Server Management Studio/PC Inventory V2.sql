Declare @CollectionID as varchar(8)
Declare @ProjectName as varchar(25)
Set @CollectionID = 'SMS00001'
Set @ProjectName = 'LAB'
Select
Distinct (VRS.Netbios_Name0) as 'Name',
Case when VRS.Client0 = 1 Then 'Yes' Else 'No' End 'Client',
Case when VRS.Active0 = 1 Then 'Yes' Else 'No' End 'Active',
Case when v_GS_SYSTEM_ENCLOSURE.ChassisTypes0 = 1 Then 'VMWare'
when v_GS_SYSTEM_ENCLOSURE.ChassisTypes0 IN('3','4')Then 'Desktop'
when v_GS_SYSTEM_ENCLOSURE.ChassisTypes0 IN('8','9','10','11','12','14') Then 'Laptop'
when v_GS_SYSTEM_ENCLOSURE.ChassisTypes0 = 6 Then 'Mini Tower'
when v_GS_SYSTEM_ENCLOSURE.ChassisTypes0 = 7 Then 'Tower'
when v_GS_SYSTEM_ENCLOSURE.ChassisTypes0 = 13 Then 'All in One'
when v_GS_SYSTEM_ENCLOSURE.ChassisTypes0 = 15 Then 'Space-Saving'
when v_GS_SYSTEM_ENCLOSURE.ChassisTypes0 = 17 Then 'Main System Chassis'
when v_GS_SYSTEM_ENCLOSURE.ChassisTypes0 = 21 Then 'Peripheral Chassis'
when v_GS_SYSTEM_ENCLOSURE.ChassisTypes0 = 22 Then 'Storage Chassis'
when v_GS_SYSTEM_ENCLOSURE.ChassisTypes0 = 23 Then 'Rack Mount Chassis'
when v_GS_SYSTEM_ENCLOSURE.ChassisTypes0 = 24 Then 'Sealed-Case PC'
Else 'Others' End 'CaseType',
LEFT(MAX(v_GS_NETWORK_ADAPTER_CONFIGUR.IPAddress0),
ISNULL(NULLIF(CHARINDEX(',',MAX(v_GS_NETWORK_ADAPTER_CONFIGUR.IPAddress0)) - 1, -
1),LEN(MAX(v_GS_NETWORK_ADAPTER_CONFIGUR.IPAddress0))))as 'IPAddress',
MAX (v_GS_NETWORK_ADAPTER_CONFIGUR.MACAddress0) as 'MACAddress',
v_RA_System_SMSAssignedSites.SMS_Assigned_Sites0 as 'AssignedSite',
VRS.Client_Version0 as 'ClientVersion',
VRS.Creation_Date0 as 'ClientCreationDate',
VRS.AD_Site_Name0 as 'ADSiteName',
dbo.v_GS_OPERATING_SYSTEM.InstallDate0 AS 'OSInstallDate',
DateDiff(D, dbo.v_GS_OPERATING_SYSTEM.InstallDate0, GetDate()) 'OSInstallDateAge',
Convert(VarChar, v_Gs_Operating_System.LastBootUpTime0,100) as 'LastBootDate',
DateDiff(D, Convert(VarChar, v_Gs_Operating_System.LastBootUpTime0,100), GetDate()) as
'LastBootDateAge',
PC_BIOS_DATA.SerialNumber00 as 'SerialNumber',
v_GS_SYSTEM_ENCLOSURE.SMBIOSAssetTag0 as 'AssetTag',
PC_BIOS_DATA.ReleaseDate00 as 'ReleaseDate',
PC_BIOS_DATA.Name00 as 'BiosName',
PC_BIOS_DATA.SMBIOSBIOSVersion00 as 'BiosVersion',
v_GS_PROCESSOR.Name0 as 'ProcessorName',
case when Computer_System_DATA.Manufacturer00 like 'VMware%' Then 'VMWare'
when Computer_System_DATA.Manufacturer00 like 'Gigabyte%' Then 'Gigabyte'
when Computer_System_DATA.Manufacturer00 like 'VIA Technologies%' Then 'VIA Technologies'
when Computer_System_DATA.Manufacturer00 like 'MICRO-STAR%' Then 'MICRO-STAR'
Else Computer_System_DATA.Manufacturer00 End 'Manufacturer',
Computer_System_DATA.Model00 as 'Model',
Computer_System_DATA.SystemType00 as 'OSType',
v_GS_COMPUTER_SYSTEM.Domain0 as 'DomainName',
VRS.User_Domain0+'\'+ VRS.User_Name0 as 'UserName',
v_R_User.Mail0 as 'EMailID',
Case when v_GS_COMPUTER_SYSTEM.domainrole0 = 0 then 'Standalone Workstation'
when v_GS_COMPUTER_SYSTEM.domainrole0 = 1 Then 'Member Workstation'
when v_GS_COMPUTER_SYSTEM.domainrole0 = 2 Then 'Standalone Server'
when v_GS_COMPUTER_SYSTEM.domainrole0 = 3 Then 'Member Server'
when v_GS_COMPUTER_SYSTEM.domainrole0 = 4 Then 'Backup Domain Controller'
when v_GS_COMPUTER_SYSTEM.domainrole0 = 5 Then 'Primary Domain Controller'
End 'Role',
case when Operating_System_DATA.Caption00 = 'Microsoft(R) Windows(R) Server 2003, Enterprise Edition'
Then 'Microsoft(R) Windows(R) Server 2003 Enterprise Edition'
when Operating_System_DATA.Caption00 = 'Microsoft(R) Windows(R) Server 2003, Standard Edition' Then
'Microsoft(R) Windows(R) Server 2003 Standard Edition'
when Operating_System_DATA.Caption00 = 'Microsoft(R) Windows(R) Server 2003, Web Edition' Then
'Microsoft(R) Windows(R) Server 2003 Web Edition'
Else Operating_System_DATA.Caption00 End 'OSName',
Operating_System_DATA.CSDVersion00 as 'ServicePack',
Operating_System_DATA.Version00 as 'Version',
((v_GS_X86_PC_MEMORY.TotalPhysicalMemory0/1024)/1000) as 'TotalRAMSize(GB)',
max(v_GS_LOGICAL_DISK.Size0 / 1024) AS 'TotalHDDSize(GB)',
v_GS_WORKSTATION_STATUS.LastHWScan as 'LastHWScan',
DateDiff(D, v_GS_WORKSTATION_STATUS.LastHwScan, GetDate()) as 'LastHWScanAge',
@ProjectName as 'AccountName'
from V_R_System VRS
Left Outer join PC_BIOS_DATA on PC_BIOS_DATA.MachineID = VRS.ResourceId
Left Outer join Operating_System_DATA on Operating_System_DATA.MachineID = VRS.ResourceId
Left Outer join v_GS_WORKSTATION_STATUS on v_GS_WORKSTATION_STATUS.ResourceID = VRS.ResourceId
Left Outer join Computer_System_DATA on Computer_System_DATA.MachineID = VRS.ResourceId
Left Outer join v_GS_X86_PC_MEMORY on v_GS_X86_PC_MEMORY.ResourceID = VRS.ResourceId
Left Outer join v_GS_PROCESSOR on v_GS_PROCESSOR.ResourceID = VRS.ResourceId
Left Outer join v_GS_SYSTEM_ENCLOSURE on v_GS_SYSTEM_ENCLOSURE.ResourceID = VRS.ResourceId
Left Outer join v_Gs_Operating_System on v_Gs_Operating_System .ResourceID = VRS.ResourceId
Left Outer join v_RA_System_SMSAssignedSites on v_RA_System_SMSAssignedSites.ResourceID =
VRS.ResourceId
left outer join v_GS_COMPUTER_SYSTEM on v_GS_COMPUTER_SYSTEM.ResourceID = VRS.ResourceId
left outer join v_FullCollectionMembership on v_FullCollectionMembership.ResourceID = VRS.ResourceId
left outer join v_GS_NETWORK_ADAPTER_CONFIGUR on v_GS_NETWORK_ADAPTER_CONFIGUR.ResourceID =
VRS.ResourceId
left outer join v_GS_LOGICAL_DISK on v_GS_LOGICAL_DISK.ResourceID = Vrs.ResourceId AND
v_GS_LOGICAL_DISK.DriveType0 = 3
Left Outer join v_R_User on VRS.User_Name0 = v_R_User.User_Name0
where VRS.Operating_System_Name_and0 like '%Workstation%'
and (VRS.Obsolete0 = 0 or VRS.Obsolete0 is null)
and v_FullCollectionMembership.CollectionID = @CollectionID
GROUP BY VRS.Netbios_Name0,VRS.Client0,VRS.Active0,v_GS_SYSTEM_ENCLOSURE.ChassisTypes0,
v_RA_System_SMSAssignedSites.SMS_Assigned_Sites0,VRS.Client_Version0,Vrs.Creation_Date0,
Vrs.AD_Site_Name0,v_Gs_Operating_System.InstallDate0,v_Gs_Operating_System.LastBootUpTime0,
PC_BIOS_DATA.SerialNumber00,v_GS_SYSTEM_ENCLOSURE.SMBIOSAssetTag0,PC_BIOS_DATA.ReleaseDate00,
PC_BIOS_DATA.Name00,PC_BIOS_DATA.SMBIOSBIOSVersion00,v_GS_PROCESSOR.Name0,Computer_System_DATA.Manufacturer00,
Computer_System_DATA.Model00,Computer_System_DATA.SystemType00,v_GS_COMPUTER_SYSTEM.Domain0,
Vrs.User_Domain0,Vrs.User_Name0,v_R_User.Mail0,v_GS_COMPUTER_SYSTEM.DomainRole0,Operating_System_DATA.Caption00,
Operating_System_DATA.CSDVersion00,Operating_System_DATA.Version00,v_GS_X86_PC_MEMORY.TotalPhysicalMemory0,v_GS_WORKSTATION_STATUS.LastHWScan
order by VRS.Netbios_Name0