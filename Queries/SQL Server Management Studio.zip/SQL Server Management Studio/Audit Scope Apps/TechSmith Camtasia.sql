Declare @CollectionID as Varchar(8)
Set @CollectionID = 'SMS00001' -- specify scope collection ID
Declare @RequirdDays as Integer
Set @RequirdDays = 140 -- specify Days
Declare @days float
Declare @__timezoneoffset int
Select @__timezoneoffset = DateDiff (ss,GetUTCDate(),Getdate())
Select @days=DATEDIFF(day,IntervalStart,DATEADD(month,1,IntervalStart))from v_SummarizationInterval
If IsNULL(@days,0) > 0
select * from (Select
Distinct VRS.Name0 as 'Name',
Os.Caption0 as 'OperatingSystem',
St.SystemType00 as 'OSType',
Vrs.Full_Domain_Name0 as 'Domain',
Vrs.User_Name0 as 'UserName',
Vrs.AD_Site_Name0 as 'ADSite',
ARP.Publisher0 as 'Publisher',
ARP.DisplayName0 as 'DisplayName',
ARP.ProdID0 as 'ProductID',
ARP.InstallDate0 as 'InstalledDate',
ARP.Version0 as 'Version',
DATEADD(ss,@__timezoneoffset,MAX(mus.LastUsage)) as 'LastUsage',
DateDiff(D, DATEADD(ss,@__timezoneoffset,MAX(mus.LastUsage)), GetDate()) as 'LastUsageDays'
from V_R_System Vrs
LEFT JOIN v_GS_ADD_REMOVE_PROGRAMS ARP ON VRS.ResourceID = ARP.ResourceID
LEFT JOIN Computer_System_DATA St on VRS.ResourceID = st.MachineID
LEFT JOIN v_GS_OPERATING_SYSTEM Os on VRS.ResourceID = Os.ResourceID
LEFT JOIN v_GS_WORKSTATION_STATUS HWSCAN on VRS.ResourceID = HWSCAN.ResourceID
LEFT JOIN v_MonthlyUsageSummary mus on Vrs.ResourceID=mus.ResourceID
LEFT JOIN v_MeteredFiles mf on mus.FileID=mf.MeteredFileID
LEFT JOIN v_FullCollectionMembership on v_FullCollectionMembership.ResourceID = VRS.ResourceId
Where ARP.Publisher0 like '%TechSmith%'
and ARP.DisplayName0 like 'Camtasia%'
and VRS.Operating_System_Name_and0 like '%Workstation%'
and v_FullCollectionMembership.CollectionID = @CollectionID
and Vrs.Obsolete0 = 0 and Vrs.Client0 = 1
Group by Vrs.Name0,Os.Caption0,St.SystemType00,Vrs.Full_Domain_Name0,Vrs.User_Name0,Vrs.AD_Site_Name0,ARP.Publisher0,ARP.InstallDate0,ARP.DisplayName0,ARP.ProdID0,ARP.Version0
Having SUM (UsageCount) + SUM (TSUsageCount) > 0 ) abc 
where  DATEDIFF(d,LastUsage, GETDATE()) > @RequirdDays
Order by 'Name'