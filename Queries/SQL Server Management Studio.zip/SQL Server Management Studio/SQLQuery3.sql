SELECT
 v_R_System.Name0 AS Computername,
 v_GS_BitLocker.ProtectionStatus0 AS [Bitlocker Status],
 v_GS_BitLocker.DriveLetter0 AS DriveLabel