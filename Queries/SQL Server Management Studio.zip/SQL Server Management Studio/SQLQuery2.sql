SELECT
  S.Name0,
  S.Operating_System_Name_and0,
  S.Is_Virtual_Machine0,
  US.Full_User_Name0,
  US.User_Name0,
  v_GS_SYSTEM_ENCLOSURE.ChassisTypes0,
  v_GS_SYSTEM_ENCLOSURE.Manufacturer0,
  v_GS_SYSTEM_ENCLOSURE.Model0,
  v_GS_X86_PC_MEMORY.TotalPhysicalMemory0,
  v_RA_System_IPAddresses.IP_Addresses0
FROM v_R_System S
LEFT JOIN v_GS_SYSTEM_ENCLOSURE
ON S.ResourceID = v_GS_SYSTEM_ENCLOSURE.ResourceID
LEFT JOIN v_RA_System_IPAddresses
ON S.ResourceID = v_RA_System_IPAddresses.ResourceID
LEFT JOIN v_GS_X86_PC_MEMORY
ON S.ResourceID = v_GS_X86_PC_MEMORY.ResourceID
LEFT JOIN 
(SELECT
  U.User_Name0,
  UPM.UserResourceID,
  UPM.MachineID,
  U.Full_User_Name0
FROM v_UsersPrimaryMachines UPM
JOIN v_R_User U
ON UPM.UserResourceID = U.ResourceID) US
ON S.ResourceID = US.MachineID
WHERE (v_RA_System_IPAddresses.IP_Addresses0 NOT LIKE '%:%')