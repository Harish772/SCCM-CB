select 
    DisplayName0, 
    Version0, 
    Count (Distinct arp.ResourceID) 
From 
    dbo.v_Add_Remove_Programs ARP 
WHERE DisplayName0 is not NULL
and DisplayName0  NOT IN ('SoftwareTitle1', 'SoftwareTitle2')
Group by 
    DisplayName0, 
    Version0 
Order by 
    DisplayName0, 
    Version0
